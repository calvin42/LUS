README

- Data is already split into train & test
Everything that contains 'train' is from training, 'test' for testing

- Files
*.data 
	token-per-line format with tokens & concept tags for sequence labeling
*.feats.txt
	POS-tag and Lemmas in token-per-line format (with tokens on first column) additional features that can be used for sequence labeling